﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Method_Overriding_Polymorphism_
{
    class Program
    {
        static void Main(string[] args)
        {
            //calling to sub class
            Sub Obj = new Sub();

            Obj.OverRiding();






            Super Obj2 = new Sub();//When using Virtual and OverRide keyword. Like the declaration of code can be call overridden class methods. And Virtual and Override keyword are must
          //  Super Obj2 = new Super();
            Obj2.OverRiding();
            


            Console.ReadLine();

        }
    }
}
