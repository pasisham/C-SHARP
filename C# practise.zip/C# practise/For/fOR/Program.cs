﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace fOR
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;
            int j;
            
            Console.Writ("Enter the number you want ");
            int number = Int16.Parse(Console.ReadLine());


            for(i=0;i<=number;i++){

                for (j = 0; j < i; j++) {

                    Console.Write("*");
                
                }

                Console.WriteLine();

            }

            Console.ReadLine();
        }
    }
}
