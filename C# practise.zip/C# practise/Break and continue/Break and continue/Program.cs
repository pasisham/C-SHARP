﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Break_and_continue
{
    class Program
    {
        static void Main(string[] args)
        {

            for (int i = 0; i < 8; i++) {

                if (i == 2 || i==4) {

                   // break;
                    continue;
                
                }
                Console.WriteLine(i);
            
            }

            Console.ReadLine();
        }
    }
}
