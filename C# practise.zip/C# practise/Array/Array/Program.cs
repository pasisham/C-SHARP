﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Array
{
    class Program
    {
        static void Main(string[] args)
        {
            //how to declare a array
            /* int [] array;
             array = new int[5];*/
            //as the above and below can be declare array

            int[] array = new int[5];

            int i; //use for the "for" loop

            for (i = 0; i < 5; i++)
            {
                Console.Write("Enter the value: ");

                array[i] = Int16.Parse(Console.ReadLine());

            }

            Console.Write("Array is ");
            for (i = 0; i < 5; i++) 
            {
                Console.Write(array[i] + "\t");
            }


            Console.ReadLine();


        }
    }
}
