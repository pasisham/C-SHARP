﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DoWhile
{
    class Program
    {
        static void Main(string[] args)
        {
            double mark=0;
            double total=0;

            do
            {
                Console.Write("Enter your mark:");
                mark = Double.Parse(Console.ReadLine());

                total = total + mark;


            } while (mark != 0);

            Console.WriteLine("Total is:"+total);
            Console.ReadLine();
        }




    }
}
