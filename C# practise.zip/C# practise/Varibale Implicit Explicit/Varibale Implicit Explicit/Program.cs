﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Varibale_Implicit_Explicit
{
    class Program
    {
        static void Main(string[] args)
        {
            //implicit casting
            int number; //Declaration
            number = 10;//Initialization

            double numberNew = number; //Implicit casting

            Console.WriteLine(number);
            Console.WriteLine(numberNew);

            Console.WriteLine("\n\n\n\n");
            
            //explicit casting

           
            double num = 10.55;
            int numNew = (int)num;
            Console.WriteLine(num);
            Console.WriteLine(numNew);


            Console.ReadLine();


        }
    }
}
