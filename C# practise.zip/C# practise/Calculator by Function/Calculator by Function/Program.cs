﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Calculator_by_Function
{
    class Program
    {
        static void Main(string[] args)
        {
            double n1;
            double n2;
            double ans;
            //int s;
            char sym;

            Console.WriteLine("Enter your values: ");
            n1 = Double.Parse(Console.ReadLine());
            n2 = Double.Parse(Console.ReadLine());

            Console.Write("Press 1 for addition \nPress 2 for multiply \t");
            //s = Int16.Parse(Console.ReadLine());
            sym = Char.Parse(Console.ReadLine());
                      
           
          switch (sym) { 
              case '+':
                    ans = Additoin(n2, n1);
                    Console.WriteLine("\nTotal is: " + ans);
                    break;
              
              case '*':
                    ans = Multiply(n2, n1);
                    Console.WriteLine("\nMultiply is: " + ans);
                    break;

              default:
                    Console.WriteLine("Error");
                    break;



            }

            Console.ReadLine();
        
        }





        static double Additoin(double num1, double num2) {

            return (num1 + num2);
        
        }

        static double Multiply(double num1, double num2) {

            return (num1 * num2);
        }

    }
}
