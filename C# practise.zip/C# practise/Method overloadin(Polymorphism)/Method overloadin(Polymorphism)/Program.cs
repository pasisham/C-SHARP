﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Method_overloadin_Polymorphism_
{
    class Program
    {
        static void Main(string[] args)
        {

            Base Object = new Base();

            Object.OverLoading();//this is 1st method without parameters





            Object.OverLoading(5);//this is onther method with parameters

            Console.ReadLine();

        }
    


    }
}
