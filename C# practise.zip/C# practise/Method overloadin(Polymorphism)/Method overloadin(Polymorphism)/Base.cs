﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Method_overloadin_Polymorphism_
{
    class Base
    {
        public void OverLoading() {

            Console.WriteLine("Here is methdo overloading 1");

        }

        public void OverLoading(int num) {

            Console.WriteLine("Here is method Overloading 2");
            //Like this can be use method overloading while changing paramters
        }
    }
}
