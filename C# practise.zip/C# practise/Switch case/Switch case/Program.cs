﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Switch_case
{
    class Program
    {
        static void Main(string[] args)
        {

            int mon;//month as user input
            Console.Write("Enter 1to 12 number to get your month ");
            mon = Int16.Parse(Console.ReadLine());

            switch (mon)
            {
                case 1:
                    Console.WriteLine("Month is January");
                    break;

                case 2:

                    Console.WriteLine("Month is February");
                    break;

                case 3:
                    Console.WriteLine("Month is March");
                    break;

                case 4:
                    Console.WriteLine("Month is April");
                    break;

                case 5:
                    Console.WriteLine("Month is May");
                    break;
                case 6:
                    Console.WriteLine("Month is June");
                    break;

                default:
                    Console.WriteLine("Error");
                    break;
                 
                    

            }

            Console.ReadLine();


        }
    }
}
