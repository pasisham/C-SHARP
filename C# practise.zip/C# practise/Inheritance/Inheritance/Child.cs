﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Inheritance
{
    class Child : Parent //child class is inherit from parent class
    {
        public string job { get; set; }

        
  
        public void getJob() {
            try
            {

                Console.Write("What is your occupation ");
                job = Console.ReadLine();

            }
            catch (Exception ex) {
                Console.WriteLine("Invalid Data"+ex);
            }

        }
        public void setJob() {
            Console.WriteLine("Your occupation is " + job);
        }


    
    }

}
