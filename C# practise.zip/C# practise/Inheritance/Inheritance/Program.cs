﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            //call to parents class
           Parent Obj1 = new Parent();

            Obj1.getDetails();
            Obj1.setDetails();

           
            


            //call to child class

            Child Obj2 = new Child();
            Obj2.getDetails();//Can be access from the parent's class
            
            Obj2.getJob();
           
            Obj2.setDetails();//Can be access from the parent's class
            Obj2.setJob();  


            Console.ReadLine();

            
        }
    }
}
