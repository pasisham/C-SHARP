﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Inheritance
{
    class Parent
    {
        public string name;
        public int age;

        //this is work as parent class
        public void getDetails()
        {

            try
            {
                Console.Write("What is your name ");
                name = Console.ReadLine();

                Console.Write("How old are you ");
                age = Int16.Parse(Console.ReadLine());
            }
            catch (Exception ex) {
                Console.WriteLine(ex);
            }



        }

        public void setDetails() {
            Console.WriteLine("\nHello " + name);
            Console.WriteLine("\nYour are " + age + " years old.\n\n");
        
        }
    }
}
