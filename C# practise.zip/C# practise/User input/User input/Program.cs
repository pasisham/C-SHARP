﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace User_input
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your name: ");
            string name = Console.ReadLine();

            Console.Write("How old are you: ");
            int age = Int16.Parse(Console.ReadLine());


            Console.WriteLine("\nHello " + name + "\nYou are " + age);


           // Console.WriteLine("\nYou are " + age);

            Console.ReadLine();

        }
    }
}
