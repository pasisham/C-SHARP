﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace If_else_condition
{
    class Program
    {
        static void Main(string[] args)
        {

            //here i am using user input

            double m1;// m1 = marks1
            double m2;// m2 = marks2
            double m3;//m3 = marks 3

            double avg;//avg =average

           

            Console.Write("Enter your mark1 ");
            m1 = Double.Parse(Console.ReadLine());

            Console.Write("\nEnter your mark2 ");
            m2 = Double.Parse(Console.ReadLine());

            Console.Write("\nEnter your mark3 ");
            m3 = Double.Parse(Console.ReadLine());

            avg= (m1+m2+m3)/3;

            if (avg >= 75) {

                Console.WriteLine("\nYour grade is A and mark is" + avg);
            }

            else if (avg >= 55)
            {

                Console.WriteLine("\nYour grade is B and mark is" + avg);
            }

            else {
                Console.WriteLine("\nYor are not allow to go more. Please try again");
            
            }

            Console.ReadLine();
        }
    }
}
