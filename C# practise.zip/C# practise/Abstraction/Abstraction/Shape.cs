﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Abstraction
{// if there is a method with abstract keyword, class also want to use abstract keyword as well
    abstract class Shape
    {
        public abstract void area();// in here this area function hasn't any body. Therefore we have to use abstract keyword.
        //area is changed by the circle, rectangle, square. So it will be implement in each class
    }
}
