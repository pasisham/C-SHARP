﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Abstraction
{
    class Program
    {
        static void Main(string[] args)
        {
            Shape obj1 = new Circle();
            //whether it is shape class ot circle class outpput is same for the above code
            obj1.area();


            Console.ReadLine();
        }
    }
}
