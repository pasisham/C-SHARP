﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Abstraction
{
    class Circle:Shape
        //Inherit from the shape class

    {
        public override void area() { //we use override keyword in here because of method overiding but not as polymorphism

            double area;
            double r;

            Console.WriteLine("Enter radius: ");
            r = Double.Parse(Console.ReadLine());

            area = 3.14 * r*r;


            Console.WriteLine("Area is " + area);


        }

    }
}
