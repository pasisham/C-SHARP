﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Exception_handling
{
    class Program
    {
        static void Main(string[] args)
        {
            int number1;
            int number2;
            int answer;
            try//this is use for the only example. And it is divideof the input value

            {
               

                Console.Write("Enter number 1: ");
                number1 = Int16.Parse(Console.ReadLine());


                Console.Write("Enter number 1: ");
                number2 = Int16.Parse(Console.ReadLine());

                answer = number1/number2;

                Console.WriteLine(answer);

            }
            catch(Exception e){

                Console.WriteLine("\nException occured: " + e.Message);
            
            }

            Console.ReadLine();
        }
    }
}
