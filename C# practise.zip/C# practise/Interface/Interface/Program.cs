﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Interface
{
    class Program
    {
        static void Main(string[] args)
        {
            Ishape Obj1 = new Circle();
            Obj1.area();

            Ishape_perimeter Obj2 = new Circle();
            Obj2.perimeter();

            Console.ReadLine();

        }
    }
}
