﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Interface
{
    class Circle : Ishape,Ishape_perimeter //can be implement multiple Interface
    {

        public void area() { // in here should want access specifier
           double area; 
           area = 3.14 * 5 * 5;

           Console.WriteLine(area);
        
        }
        public void perimeter() {

            double peri;
            peri = 2 * 3.14 * 5;
            Console.WriteLine(peri);
        
        }
    }
}
