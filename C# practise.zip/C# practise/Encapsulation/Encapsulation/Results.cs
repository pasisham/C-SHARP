﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Encapsulation
{
    class Results
    {
        public string index;
        private string name;
        public double results;
        public double marks;

   
        /*
         public name{get;set;}*/
        //here done as shorter method

        //Here name is a private variable and below from get and set it has done to public that can accessible(loneger method)
        public string Name {
            get { 
             return name;
            }
            set {
                name = value;
            }
        }

        //this is for getting value
        public double getValue() {

            Console.WriteLine("Enter your Index and name please");

            index= Console.ReadLine();
            Name = Console.ReadLine();


            for (int i = 1; i <= 10; i++) {

                Console.Write("Enter your mark " + i + ":");
                marks = Int16.Parse(Console.ReadLine());

                results = results + marks;
                           
            
            }
            return (results);
        }

        //this is for diplay the value
        public void display() {

            Console.Write("Your index number is " + index + "\nName is " + Name + "\n And your result is " + results/10);
            Console.ReadLine();
        }



    }
}
