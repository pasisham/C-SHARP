﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Encapsulation
    //this is a short example for the encapsulation. Encapsulation mean is, buuilding a properties and methods in to single unit that is like capsule.
{
    class Program
    {
        static void Main(string[] args)
        {
            Results student1= new Results();

            student1.getValue();
            student1.display();
        }
    }
}
