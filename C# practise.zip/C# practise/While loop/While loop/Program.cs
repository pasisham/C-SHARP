﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace While_loop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i=1;
            double mark;
            double total=0;
            double average;

            while (i <= 10) {

                Console.Write("Enter your mark " + i + ": ");
                mark = Double.Parse(Console.ReadLine());

                total = total + mark;

                i++;
            
            }
            average = total / 10;

            Console.WriteLine("Total is " + total);
            Console.WriteLine("Average is " + average);

            Console.ReadLine();


        }
    }
}
