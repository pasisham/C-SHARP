﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Operator
{
    class Program
    {
        static void Main(string[] args)
        {
            int num1 = 10;
            int num2 = 20;
            Console.WriteLine(num1 == num2);
            Console.WriteLine(num1<=num2);

            //In this output is showed as Boolean


            Console.ReadLine();

        }
    }
}
